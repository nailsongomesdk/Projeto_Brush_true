#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "funcoes.h"


int main() {

		int i,j;
    Matriz *matriz;
    
		
		matriz = image(400, 600);

		clear(matriz, 10, 10, 10);

		line(0, 100, 100, 100, matriz);

		save("temp.txt", matriz);
		



		/*for(i = 0; i < matriz->linhas;i++){
			for(j = 0; j < matriz->colunas; j++){
				matriz->matriz[i][j].r = i;
				matriz->matriz[i][j].g = j;

				printf("%d %d\n", matriz->matriz[i][j].r, matriz->matriz[i][j].g);
			}
		}



		


		
		/*  matriz_imagem = ler_arquivo_txt("teste2.txt", &largura , &altura , rgb_color , rgb_clear);
    if (teste2 == NULL) {
        printf("Arquivo nao eh PPM P3 ou nao existe");
        return 1;
    }
    salvar_imagem_ppm("imagemsaida.ppm", matriz_imagem);*/
    return 0;
}




#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "funcoes.h"

void funcoes(){

	
}

 /** void colocar_pixel(int x, int y,int largura, Pixel_1 rgb_color ) {
    int mempos = (x*4)+(y*largura*4);
    FBptr[mempos] = rgb_color.r
    FBptr[mempos+1] = rgb_color.g
    FBptr[mempos+2] = rgb_color.b
  }  **/

	Pixel_1 **imagem(int largura, int altura){
		int i;

		Pixel_1 **matriz_imagem = (Pixel_1 **) malloc(sizeof(Pixel_1*) * altura);

		for(i = 0; i < altura; i++){
			*(matriz_imagem+i) = (Pixel_1*) malloc(sizeof(Pixel_1) * largura);
		}

		return matriz_imagem;
	}

  Matriz *image(int largura, int altura){
    int i;

		//alocação para a matriz de baixo;
    int **matriz_imagem = (int **) malloc(sizeof(int*) * largura);
    
		for(i = 0; i < altura; i++){
			*(matriz_imagem+i) = (int*) malloc(sizeof(int) * altura);
		}

		Matriz *matriz = (Matriz*) malloc(sizeof(Matriz));
		matriz->linhas = altura;
		matriz->colunas = largura;
		//aqui é pixel_1
		matriz->matriz = (Pixel_1**) matriz_imagem;
		
    return matriz;
  }

	void clear(Matriz *matriz, int r, int g, int b){
		int x, y;

    for (y = 0; y < matriz->linhas; y++) {
        for (x = 0; x < matriz->colunas; x++) {
           matriz->matriz[x][y].r = r;
					 matriz->matriz[x][y].g = g;
					 matriz->matriz[x][y].b = b;
        }
    }
  }

 	void save(const char *nome_arquivo, Matriz *matriz){
    FILE *arq = fopen(nome_arquivo, "w");
    int x, y;

		fprintf(arq, "P3\n");
		fprintf(arq, "%d %d\n255", matriz->linhas, matriz->colunas);

    for (y = 0; y < matriz->linhas; y++) {
        for (x = 0; x < matriz->colunas; x++) {
           fprintf(arq, "\n%d %d %d", matriz->matriz[x][y].r, matriz->matriz[x][y].g, matriz->matriz[x][y].b);
        }
    }
    fclose(arq);
	}

	void line(int x1, int y1, int x2, int y2, Matriz *matriz){
		int dx = x2-x1;
		int dy = y2-y1;
		int d=2*dy-dx; /* Valor inicial da var. decisao */
		int incrE = 2*dy; /* incremento p/ mover E */
		int incrNE = 2*(dy-dx); /* incremento p/ mover NE */
		int x=x1;
		int y=y1;

		putPixel(x,y,255,255,255,matriz); /* Primeiro pixel */
		while (x < x2) {
		if (d<=0) { /* Escolha E */
		d+=incrE;
		x++;
		} else { /* Escolha NE */
		d+=incrNE;
		x++;
		y++;
		}
		putPixel(x,y,255,255,255,matriz);
		} 

	}

	/*void line(int x1, int y1, int x2, int y2, Matriz *matriz){
		int i, x = x1, y = y1, dx, dy, c = -x1 * y2 + x2 * y1;
		float calcAng, midx, midy, d;

		for(x = x1; x <= x2; x++){
			dx = x * (-y2 + y1);
			dy = y * (x2 - x1);
			calcAng = (float)dy/dx;
			midx = x1 + 1.0;
			midy = y1 + ( calcAng >= 0 ? 0.5 : -0.5 );
			d = -dx*midy + dy*midx + c;

			if(d <= 0){
				calcAng < 0 ? putPixel(i, y-1, 255, 255, 255, matriz) : putPixel(i, y, 255, 255, 255, matriz);
			}else{
				calcAng >= 0 ? putPixel(i, y+1, 255, 255, 255, matriz) : putPixel(i, y, 255, 255, 255, matriz);
			}
		}

	}*/

	void putPixel(int x, int y, int r, int g, int b, Matriz *matriz){
		matriz->matriz[x][y].r = r;
		matriz->matriz[x][y].g = g;
		matriz->matriz[x][y].b = b;
	}

	void inverterPonto(int x1, int y1, int x2, int y2){
		//inverte x;
		int aux = x1;
		x1 = x2;
		x2 = aux;

		//inverte y;
		aux = y1;
		y1 = y2;
		y2 = aux;	

	}


  /*Pixel_1 **ler_arquivo_txt(const char *nome_arquivo , int *largura , int *altura , Pixel_1 *rgb_color , Pixel_1 *rgb_clear) {

      int n_pontos =0 ;
      int j;
      ponto p1 , p2 , paux;

    FILE *arq = fopen(nome_arquivo, "r");
    if (arq == NULL){
      printf ("Erro - arquivo não encontrado\n");
      return NULL;} 

    Pixel_1 **matriz_imagem = NULL;
    char teste_funcao[9];

		while(fscanf (arq , "%s" , teste_funcao)){
    if (strcmp("image", teste_funcao) == 0) {
        fscanf(arq, "%d", largura);
        fscanf(arq, "%d", altura);
        matriz_imagem = image(*largura, *altura);
         }
				 
		else if(strcmp("clear", teste_funcao) == 0){
			fscanf(arq, "%d", &rgb_clear->r);
      fscanf(arq, "%d", &rgb_clear->g);
			fscanf(arq, "%d", &rgb_clear->b);
			matriz_imagem = clear(*(rgb_clear), *largura, *altura);
				 }
    else if(strcmp("color", teste_funcao) == 0){
			fscanf(arq, "%d", &rgb_color->r);
      fscanf(arq, "%d", &rgb_color->g);
			fscanf(arq, "%d", &rgb_color->b);
				 }

    else if(strcmp("line", teste_funcao) == 0){

			fscanf(arq, "%d", &p1.x);
      fscanf(arq, "%d", &p1.y);
      fscanf(arq, "%d", &p2.x);
      fscanf(arq, "%d", &p2.y);
			matriz_imagem = line(p1, p2, rgb_color);
				 }

		else if(strcmp("polygon", teste_funcao) == 0){

			fscanf(arq, "%d", &n_pontos);
      fscanf(arq, "%d", &p1.x);
      fscanf(arq, "%d", &p1.y);
      fscanf(arq, "%d", &p2.x);
      fscanf(arq, "%d", &p2.y);
			matriz_imagem = line(p1, p2, rgb_color);
      for(j = 0;j <= n_pontos-2;j++){
        paux.x = p2.x;
        paux.y = p2.y;
        fscanf(arq, "%d", &p2.x);
        fscanf(arq, "%d", &p2.y);
        matriz_imagem = line(paux, p2, rgb_color);
              }
        matriz_imagem = line(p2, p1, rgb_color);      
			 }



		}
    fclose(arq);
    return matriz_imagem;
}





void line(ponto p1, ponto p2, Pixel_1 rgb_color){
    int dx = p2.x - p1.x;
    int dy = p2.y - p1.y;
    int inclinacao=0;    
    if(dx<0) // caso ponto final < ponto inicial
    {
        line(p2,p1,rgb_color);
        return;
    }
    if(dy<0)
        inclinacao = -1;
    else
        inclinacao = 1;

    int incE, incNE, d;

    ponto pixel = p1;

    PutPixel(pixel,rgb_color,*largura, matriz);
    if(dx >= inclinacao*dy){    // m<=1
        if(dy<0){ // caso y2<y1
            d = 2*dy+dx;
            while(pixel.x<p2.x){
                if(d<0){ // escolhido é o I
                    d += 2*(dy+dx);
                    pixel.x++;
                    pixel.y--;
                }
                else{ // escolhido é o S
                    d+=2*dy;
                    pixel.x++; // varia apenas no eixo x
                }
                PutPixel(pixel,rgb_color,*largura, matriz);
            }
        }
        else{ // caso y1<y2
            d=2*dy-dx;
            while(pixel.x<p2.x){
                if(d<0){ // escolhido é o I
                    d+=2*dy;
                    pixel.x++; // varia apenas no eixo x
                }
                else{ // escolhido é o S
                    d+=2*(dy-dx);
                    pixel.x++;
                    pixel.y++;
                }
		PutPixel(pixel,rgb_color,*largura, matriz);
            }
        }
    }
    else{ // |m|>1
        if(dy<0){ // caso y2<y1
            d=dy+2*dx;
            while(pixel.y > p2.y){
                if(d<0){
                    d += 2*dx;
                    pixel.y--; // varia apenas no eixo y
                }
                else{
                    d+=2*(dy+dx);
                    pixel.x++;
                    pixel.y--;
                }
	PutPixel(pixel,rgb_color,*largura, matriz);
            }
        }
        else{ // caso y1<y2
            d=dy-2*dx;
            while(pixel.y<p2.y){
                if(d<0){
                    d+=2*(dy-dx);
                    pixel.x++;
                    pixel.y++;
                }
                else{
                    d+=-2*dx;
                    pixel.y++; // varia apenas no eixo y
                }
                PutPixel(pixel,rgb_color,*largura, matriz);
                }
            }
        }
    PutPixel(p2,rgb_color);
}*/


typedef struct Pixel_1 {
   	unsigned int r, g , b; 
} Pixel_1;

typedef struct{
	unsigned int linhas, colunas;
	Pixel_1 **matriz;
} Matriz;

typedef struct ponto {
    unsigned int x , y;
} ponto;


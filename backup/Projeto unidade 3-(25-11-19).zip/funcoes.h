#include "estruturas.h"
#ifndef FUNCOES_H_INCLUDED
#define FUNCOES_H_INCLUDED

/**********************************************************************************************

**********************************************************************************************/
Matriz *image(int largura, int altura);

void clear(Matriz *matriz, int r, int g, int b);

void save(const char *nome_arquivo, Matriz *matriz);

void line(int x1, int y1, int x2, int y2, Matriz *matriz);

void putPixel(int x, int y, int r, int g, int b, Matriz *matriz);


#endif

typedef struct pixel_cor {
    int vermelho, verde, azul;
} pixel_cor;

typedef struct imagem_dados {
    int largura;
    int altura;
    int cor_maxima;
    pixel_cor *pixels;
} imagem_dados;

typedef struct linha{

}Linha;



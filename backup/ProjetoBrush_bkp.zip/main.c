#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "estruturas.h"
#include "funcoes.h"


int main() {
    imagem_dados *teste = ler_arquivo_txt("teste.txt");
    if (teste == NULL) {
        printf("Arquivo nao eh PPM P3 ou nao existe");
        return 1;
    }
    salvar_imagem_ppm("imagemsaida.ppm", teste);
    return 0;
}


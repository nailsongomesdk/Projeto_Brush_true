
/**********************************************************************************************

**********************************************************************************************/

imagem_dados *criar_imagem(int largura, int altura, int cor_maxima) {
    imagem_dados *imagem = (imagem_dados *) malloc(sizeof(imagem_dados));
    imagem->pixels = (pixel_cor *) malloc(largura * altura * sizeof(pixel_cor));
    imagem->largura = largura;
    imagem->altura = altura;
    imagem->cor_maxima = cor_maxima;
    return imagem;
}

/**********************************************************************************************
Esta fórmula y * imagem->largura + x é porque cada linha corresponde a um bloco de largura pixels, sendo todas as linhas armazenadas contiguamente na memória em um único bloco maior. Assim sendo, cada posição que variar no y ocasiona uma variação de largura posições dentro do bloco maior. Isso serve para não precisar alocar cada linha uma por um, otimizando a memória ao fazer todos os pixels serem alocados na mesma região de memória.
**********************************************************************************************/
pixel_cor *pixel_da_imagem(imagem_dados *imagem, int x, int y) {
    return &(imagem->pixels[y * imagem->largura + x]);
}

/**********************************************************************************************

**********************************************************************************************/
imagem_dados *ler_arquivo_txt(const char *nome_arquivo) {
    FILE *arq = fopen(nome_arquivo, "r");
    if (arq == NULL){
      printf ("Erro - arquivo não encontrado\n");
      return NULL;} 

    int largura, altura, cor_maxima, x, y;
    imagem_dados *imagem = NULL;
    char teste_formato[6];
    fgets(teste_formato, 6, arq);
    if (strcmp("P3\n", teste_formato) == 0) {
        fscanf(arq, "%d", &largura);
        fscanf(arq, "%d", &altura);
        fscanf(arq, "%d", &cor_maxima);
        imagem = criar_imagem(largura, altura, cor_maxima);
        for (y = 0; y < altura; y++) {
            for (x = 0; x < largura; x++) {
                pixel_cor *pont_pixel = pixel_da_imagem(imagem, x, y);
                fscanf(arq, "%d", &(pont_pixel->vermelho));
                fscanf(arq, "%d", &(pont_pixel->verde));
                fscanf(arq, "%d", &(pont_pixel->azul));
            }
        }
    }
    fclose(arq);
    return imagem;
}

/**********************************************************************************************

**********************************************************************************************/
void salvar_imagem_ppm(const char *nome_arquivo, imagem_dados *imagem) {
    FILE *arq = fopen(nome_arquivo, "w");
    int x, y;
    fprintf(arq, "P3\n%d %d\n%d", imagem->largura, imagem->altura, imagem->cor_maxima);
    for (y = 0; y < imagem->altura; y++) {
        for (x = 0; x < imagem->largura; x++) {
            pixel_cor *pont_pixel = pixel_da_imagem(imagem, x, y);
            fprintf(arq, "\n%d %d %d", pont_pixel->vermelho, pont_pixel->verde, pont_pixel->azul);
        }
    }
    fclose(arq);
}

/**********************************************************************************************
Função para limpar a imagem caso necessario 
**********************************************************************************************/
void clear_imagem(imagem_dados *imagem) {
    free(imagem->pixels);
    free(imagem);
}